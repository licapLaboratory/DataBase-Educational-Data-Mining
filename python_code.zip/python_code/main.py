###################################################################################################################
# Imports
import time
import sys
import author_list
import java_interface
###################################################################################################################

accept = ['y', 'yes', 'sim', 's', '1']
reject = ['n', 'no', 'nao', 'não', 'n', '0']

###################################################################################################################
# Main
def main():
    al = author_list.AuthorList()
    al.load_tsv("C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/data2.tsv")
    if (len(sys.argv) > 1 and sys.argv[1] == '-c'):
        pass
    else:
        quit = False
        while not quit:
            query_result = {}
            search_objects = False
            search_attributes = False
            search_conditions = False
            filter_categories = {
                "exato": False,
                "especializado": False,
                "generalizado": False,
                "parcial": False,
                "novo": False,
            }

            dim_count = 0
            # Ask user for which inputs to be used
            e = (input(f"""Deseja pesquisar com Objetos? (y/n):"""))
            if e in accept:
                search_objects = True
                dim_count += 1
            e = (input(f"""Deseja pesquisar com Atributos? (y/n):"""))
            if e in accept:
                search_attributes = True
                dim_count += 1
            e = (input(f"""Deseja pesquisar com Condicoes? (y/n):"""))
            if e in accept:
                search_conditions = True
                dim_count += 1
            
            # "Decision tree" to pick which search to use
            if (not search_objects and not search_conditions and not search_attributes):
                print("Pesquisa inválida")
            else:
                if search_objects:
                    if search_attributes:
                        if search_conditions:
                            query_result = Busca3D(verbose=True)
                        else:
                            query_result = Busca2D(0,1,verbose=True)
                    elif search_conditions:
                        query_result = Busca2D(0,2,verbose=True)
                    else:
                        query_result = Busca1D(0,verbose=True)
                elif search_attributes:
                    if search_conditions:
                        query_result = Busca2D(1,2,verbose=True)
                    else:
                        query_result = Busca1D(1,verbose=True)
                else:
                    query_result = Busca1D(2,verbose=True)
            
            # Ask if user wants to filter results
            if dim_count == dim_count:
                e = (input(f"""Deseja filtrar conceitos exatos? (y/n):"""))
                if e in accept:
                    filter_categories["exato"] = True
                e = (input(f"""Deseja filtrar conceitos generalizados? (y/n):"""))
                if e in accept:
                    filter_categories["generalizado"] = True
                e = (input(f"""Deseja filtrar conceitos especializados? (y/n):"""))
                if e in accept:
                    filter_categories["especializado"] = True
                e = (input(f"""Deseja filtrar conceitos parcialmente novos? (y/n):"""))
                if e in accept:
                    filter_categories["parcial"] = True
                e = (input(f"""Deseja filtrar conceitos totalmente novos? (y/n):"""))
                if e in accept:
                    filter_categories["novo"] = True

            print("##############################################################\n")
            print("Pesquisa: ", end= '')
            for dim in query_result["original_query"]:
                print(dim)
            print (f'Runtime: {query_result["runtime"]}')
            printListOfConcepts(query_result["concepts"], filter_categories)
            print("##############################################################\n")
            
            e = (input(f"""Deseja pesquisa novamente? (y/n):"""))
            if e in reject or not e in accept:
                quit = True


###################################################################################################################

###################################################################################################################
# Functions

def Busca1D(dim, verbose = False):
    result_dict = {
        'original_query': [],
        'runtime': 0.0,
        'concepts': {},
    }
    match dim:
        case 0:
            dimensao = obterObjetosIO(verbose)
        case 1:
            dimensao = obterAtributosIO(verbose, False)
        case 2:
            dimensao = obterCondicoesIO(verbose)
        case _:
            print("Invalid dimension")
            return
    result_dict['original_query'].append(dimensao)
    #Retorna se houve algum problema
    if len(dimensao) < 0: 
        return
    # Transformar os topicos em uma query para o programa em Java
    query = []
    match dim:
        case 0:
            query.append(java_interface.objectsToQuery(dimensao))
        case 1:
            query.append(java_interface.attributesToQuery(dimensao))
        case 2:
            query.append(java_interface.conditionsToQuery(dimensao))
    # Mandar e receber os dados do programa em Java   
    start_time = time.time()
    java_output = java_interface.runJavaProgram(query)
    end_time = time.time()
    result_dict['runtime'] = end_time - start_time
    # Categorizar dados recebidos
    concepts = None
    if hasAnyConcepts(java_output):
        match dim:
            case 0:
                concepts = formatConcepts(java_output, original_objects=dimensao)
            case 1:
                concepts = formatConcepts(java_output, original_attributes=dimensao)
            case 2:
                concepts = formatConcepts(java_output, original_conditions=dimensao)
        result_dict['concepts'] = concepts
        return result_dict
    else:
        return result_dict

def Busca2D(dim0, dim1, verbose = False):
    result_dict = {
        'original_query': [],
        'runtime': 0.0,
        'concepts': {},
    }
    if dim0 > dim1:
        return
    if dim0 == dim1:
        return
    match dim0:
        case 0:
            dimensao0 = obterObjetosIO(verbose)
        case 1:
            dimensao0 = obterAtributosIO(verbose, False)
        case 2:
            dimensao0 = obterCondicoesIO(verbose)
        case _:
            print("Invalid dimension")
            return 
    match dim1:
        case 0:
            dimensao1 = obterObjetosIO(verbose)
        case 1:
            dimensao1 = obterAtributosIO(verbose, False)
        case 2:
            dimensao1 = obterCondicoesIO(verbose)
        case _:
            print("Invalid dimension")
            return 
    result_dict['original_query'].append(dimensao0)
    result_dict['original_query'].append(dimensao1)
    #Retorna se houve algum problema
    if len(dimensao0) < 0 or len(dimensao1) < 0: 
        return 
    # Transformar os topicos em uma query para o programa em Java
    query = []
    match dim0:
        case 0:
            query.append(java_interface.objectsToQuery(dimensao0))
        case 0:
            query.append(java_interface.attributesToQuery(dimensao0))
        case 2:
            query.append(java_interface.conditionsToQuery(dimensao0))
    match dim1:
        case 0:
            query.append(java_interface.objectsToQuery(dimensao1))
        case 1:
            query.append(java_interface.attributesToQuery(dimensao1))
        case 2:
            query.append(java_interface.conditionsToQuery(dimensao1))
    # Mandar e receber os dados do programa em Java   
    start_time = time.time()
    java_output = java_interface.runJavaProgram(query)
    end_time = time.time()
    result_dict['runtime'] = end_time - start_time
    # print("--- %s seconds ---" % (end_time - start_time))
    # Categorizar dados recebidos
    concepts = None
    if hasAnyConcepts(java_output):
        if dim0 == 0:
            if dim1 == 1:
                concepts = formatConcepts(java_output, original_objects=dimensao0, original_attributes=dimensao1)
            elif dim1 == 2:
                concepts = formatConcepts(java_output, original_objects=dimensao0, original_conditions=dimensao1)
        if dim0 == 1:
            if dim1 == 2:
                concepts = formatConcepts(java_output, original_attributes=dimensao0, original_conditions=dimensao1)
        result_dict['concepts'] = concepts
        return result_dict
    else:
        return result_dict

def Busca3D(verbose = False):
    result_dict = {
        'original_query': [],
        'runtime': 0.0,
        'concepts': {},
    }
    dimensao0 = obterObjetosIO(verbose)
    result_dict['original_query'].append(dimensao0)
    dimensao1 = obterAtributosIO(verbose, False)
    result_dict['original_query'].append(dimensao1)
    dimensao2 = obterCondicoesIO(verbose)
    result_dict['original_query'].append(dimensao2)
    #Retorna se houve algum problema
    if (len(dimensao0) < 0) or (len(dimensao1) < 0) or (len(dimensao2) < 0): 
        return
    # Transformar os topicos em uma query para o programa em Java
    query = []
    query.append(java_interface.objectsToQuery(dimensao0))
    query.append(java_interface.attributesToQuery(dimensao1))
    query.append(java_interface.conditionsToQuery(dimensao2))
    # Mandar e receber os dados do programa em Java
    start_time = time.time()
    java_output = java_interface.runJavaProgram(query)
    end_time = time.time()
    result_dict['runtime'] = end_time - start_time
    # print("--- %s seconds ---" % (end_time - start_time))
    # Categorizar dados recebidos
    if hasAnyConcepts(java_output):
        concepts = formatConcepts(java_output,
                              original_objects=dimensao0, 
                              original_attributes=dimensao1,
                              original_conditions=dimensao2)
        result_dict['concepts'] = concepts
        return result_dict
    else:
        return result_dict

def BuscaComRepesquisa(verbose = False):
    # Obter topicos para se fazer a pesquisa
    topicos = obterAtributosIO(True, False)
    #Retorna se houve algum problema
    if len(topicos) < 0: 
        return
    # Transformar os topicos em uma query para o programa em Java
    query = []
    query.append(java_interface.attributesToQuery(topicos))
    # Mandar e receber os dados do programa em Java    
    java_output = java_interface.runJavaProgram(query)
    # Categorizar dados recebidos
    if hasAnyConcepts(java_output):
        concepts = formatConcepts(java_output, original_attributes=topicos)
    else:
        print("No concepts found!!!")
        return
    # Mostrar Conceitos
    print("##############################################################\n")
    print("Pesquisa: ", end= '')
    print(topicos)
    printListOfConcepts(concepts, [])
    print("##############################################################\n")

    # Repesquisar o conceito escolhido
    if verbose:
        chosenConcept = int(input("Escolha conceito para se realizar a subpesquisa: "))
    else:
        chosenConcept = int(input())

    # Decidir quais dimensoes serao repesquisadas 
    if verbose:
        # abc | a, b, c E (0 U 1)
        # a -> objetos, b -> atributos, c -> condicoes
        # ex.: 101, Repesquisa nas dimensao objetos e condicoes
        chosenDimensions = (input("Escolha dimensoes nas quais se realizara a subpesquisa: "))
    else:
        chosenDimensions = (input())

    if chosenConcept < len(concepts):
        query = []
        if chosenDimensions[0] == '1':
            query.append(java_interface.objectsToQuery(concepts[chosenConcept].get("objects")))
        if chosenDimensions[1] == '1':            
            query.append(java_interface.attributesToQuery(concepts[chosenConcept].get("attributes")))
        if chosenDimensions[2] == '1':
            query.append(java_interface.conditionsToQuery(concepts[chosenConcept].get("conditions")))
            
        new_output = java_interface.runJavaProgram(query)

        if hasAnyConcepts(new_output):         
            objs = []
            atts = []
            cons = []               
            if chosenDimensions[0] == '1':
                objs = concepts[chosenConcept].get("objects")
            if chosenDimensions[1] == '1':            
                atts = concepts[chosenConcept].get("attributes")
            if chosenDimensions[2] == '1':
                cons = concepts[chosenConcept].get("conditions")
            new_concepts = formatConcepts(new_output, original_objects=objs, original_attributes=atts, original_conditions=cons)
        else:
            print("No concepts found!!!")
            return
                
        print("##############################################################\n")
        print("Pesquisa: ", end= '')

        if chosenDimensions[0] == '1':
            if len(concepts[chosenConcept].get("objects")) > 5:
                print(concepts[chosenConcept].get("objects")[0:5], end="... + ")
                print(len(concepts[chosenConcept].get("objects")) - 5)
            else:
                print(concepts[chosenConcept].get("objects"))
        if chosenDimensions[1] == '1':            
            print(concepts[chosenConcept].get("attributes"))
        if chosenDimensions[2] == '1':
            print(concepts[chosenConcept].get("conditions"))
            
        print("")
        printListOfConcepts(new_concepts, [])
        print("##############################################################\n")
    else: 
        print("Conceito escolhido nao e' valido")  

def BuscaSemRepesquisa(verbose = False):
    # Obter topicos para se fazer a pesquisa
    topicos = obterAtributosIO(True, False)
    #Retorna se houve algum problema
    if len(topicos) < 0: 
        return
    # Transformar os topicos em uma query para o programa em Java
    query = []
    query.append(java_interface.attributesToQuery(topicos))
    # Mandar e receber os dados do programa em Java    
    java_output = java_interface.runJavaProgram(query)
    # Categorizar dados recebidos
    if hasAnyConcepts(java_output):
        concepts = formatConcepts(java_output, original_attributes=topicos)
    else:
        print("No concepts found!!!")
        return
    # Mostrar Conceitos
    print("##############################################################\n")
    print("Pesquisa: ", end= '')
    print(topicos)
    printListOfConcepts(concepts, [])
    print("##############################################################\n")

def formatConcepts(concepts, original_objects = [], original_attributes = [], original_conditions = []):
    conceptsClassified = []

    separated = separateJavaOutput(concepts)
    
    for concept in separated:
        conceptDict = {
            "objects": concept[0].replace(" ", "").split(","),
            "attributes": concept[1].replace(" ", "").split(","),
            "conditions": concept[2].replace(" ", "").split(","),
            "object_type": classifyConcepts(concept[0].replace(" ", "").split(","), original_objects),
            "attribute_type": classifyConcepts(concept[1].replace(" ", "").split(","), original_attributes),
            "condition_type": classifyConcepts(concept[2].replace(" ", "").split(","), original_conditions)
        }
        conceptsClassified.append(conceptDict)
    
    return conceptsClassified 

def classifyConcepts(dimension, originalDimension):
    dim0 = set(dimension)
    dim1 = set(originalDimension)

    if len(originalDimension) <= 0:
        return "no_original_dimension"
    elif dim0 == dim1:
        return "exato"
    elif dim1.issubset(dim0):
        return "generalizado"
    elif dim0.issubset(dim1):
        return "especializado"
    elif dim0.isdisjoint(dim1):
        return "novo"
    else:
        return "parcial"

def getQueriedAttributes(javaOutput, is2D = False):
    formattedOutput = []
    # Parse output
    originalQuery = (javaOutput.splitlines())[1]
    originalQuery = originalQuery[9:-5]

    if not is2D:
        formattedOutput = originalQuery.replace(" ", "").split(",")
    else:
        formattedOutput = originalQuery.replace(" ", "").split("],")[1].replace("[", "").split(",")

    return formattedOutput   

def separateJavaOutput(javaOutput):
    formattedOutput = []
    # Parse output
    output_lines = (javaOutput.splitlines()[2:])[:-2]
    for line in output_lines:
        parts = (line.split('],'))
        formattedOutput.append((clearCharacters(parts[0], '[','(',')', '{', '}', ']'), clearCharacters(parts[1], '[','(',')', '{', '}', ']'), clearCharacters(parts[2], '[','(',')', '{', '}', ']')))
    return formattedOutput   

def clearCharacters(originalString, *characters):
    newString = originalString
    for char in characters:
        newString = newString.replace(char, '')
    return newString

def hasAnyConcepts(javaOutput):
    output = (javaOutput.splitlines()[2:])[:-2]
    
    return output[0] != '{}'

def printListOfConcepts(list_of_concepts, filter_list, limitOfObjects = 5):
    for i, concept in enumerate(list_of_concepts):
        if not filtered(concept, filter_list):
            print(str(i) + ": ", end="")
            printConcept(concept, limitOfObjects)
            print()

def filtered(concept, filter_list):
    concept_types = [concept.get("object_type"), concept.get("attribute_type"), concept.get("condition_type")]
    for concept_type in concept_types:
        if not (concept_type == "no_original_dimension") and filter_list[str(concept_type)]:
            return True
    return False
    

def printConcept(concept, limitOfObjects = 5):
    print()
    match concept.get("object_type"):
        case "exato":
            print("Correspondencia exata de objetos")
        case "generalizado":
            print("Correspondencia generalizada de objetos")
        case "especializado":
            print("Correspondencia especializada de objetos")
        case "parcial":
            print("Correspondencia parcialmente nova de objetos")
        case "novo":
            print("Correspondencia totalmente nova de objetos")
        case _:
            print("", end='')

    match concept.get("attribute_type"):
        case "exato":
            print("Correspondencia exata de atributos")
        case "generalizado":
            print("Correspondencia generalizada de atributos")
        case "especializado":
            print("Correspondencia especializada de atributos")
        case "parcial":
            print("Correspondencia parcialmente nova de atributos")
        case "novo":
            print("Correspondencia totalmente nova de atributos")        
        case _:
            print("", end='')

    match concept.get("condition_type"):
        case "exato":
            print("Correspondencia exata de condicoes")
        case "generalizado":
            print("Correspondencia generalizada de condicoes")
        case "especializado":
            print("Correspondencia especializada de condicoes")
        case "parcial":
            print("Correspondencia parcialmente nova de condicoes")
        case "novo":
            print("Correspondencia totalmente nova de condicoes")        
        case _:
            print("", end='')

    if len(concept.get("objects")) > limitOfObjects:
        print(concept.get("objects")[0:limitOfObjects], end="... + ")
        print(len(concept.get("objects")) - limitOfObjects)
    else:
        print(concept.get("objects"))
    print(concept.get("attributes"))
    print(concept.get("conditions"))

def obterObjetosIO(verbose = True):
    objetos = []
    if verbose:
        objeto = input("Insira objetos para pesquisa (0 para terminar): ").replace(" ", "_")
    else:
        objeto = input().replace(" ", "_")
    while (objeto != '0'):
        objetos.append(objeto)
        if verbose:
            objeto = input("Insira objeto para pesquisa (0 para terminar): ").replace(" ", "_")
        else:
            objeto = input().replace(" ", "_")
    return objetos

def obterAtributosIO(verbose = True, comAtributosRedundantes = False):
    atributos = [
        "Traditional_classroom","eLearning",
        "Educator","Tutor","Administrator",
        "Coordinator","Classroom","Virtual_classroom",
        "Teaching_plan","Student_groups",
        "Interdisciplinary","Multimedia",
        "Monitoring","Personalization","Evaluation"
                 ]
    atributosRedundantes = ["Teaching", "Learning", "Student"]
    if comAtributosRedundantes:
        atributos = [*atributos, *atributosRedundantes]
    topicos = []
    if verbose:
        topico = input("Insira tópico para pesquisa (0 para terminar): ").replace(" ", "_")
    else:
        topico = input().replace(" ", "_")
    while (topico != '0'):
        if topico in atributos:
            topicos.append(topico)
        else:
            print("Erro - Atributo nao existente!")
            return
        if verbose:
            topico = input("Insira tópico para pesquisa (0 para terminar): ").replace(" ", "_")
        else:
            topico = input().replace(" ", "_")
    return topicos

def obterCondicoesIO(verbose = True):
    condicoes = ["1994-1999", "2000-2005", "2006-2011", "2012-2017", "2018-2020"]
    periodos = []
    if verbose:
        print('"1994-1999", "2000-2005", "2006-2011", "2012-2017", "2018-2020" disponíveis')
        condicao = input("Insira período de tempo para pesquisa (0 para terminar): ")
    else:
        condicao = input().replace(" ", "_")
    while (condicao != '0'):
        if condicao in condicoes:
            periodos.append(condicao)
        else:
            print("Erro - Período nao existente!")
            return
        if verbose:
            condicao = input("Insira período para pesquisa (0 para terminar): ").replace(" ", "_")
        else:
            condicao = input().replace(" ", "_")
    return periodos

###################################################################################################################

###################################################################################################################
# Execution
main()
# debug()
###################################################################################################################