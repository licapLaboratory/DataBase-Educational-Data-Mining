class Article:
    def __init__(self, bibtexID, year, title, abstract, keywords, review, type, source, idgen, idnew, doi, attributes):
        self.bibtexID = bibtexID
        self.year = year
        self.title = title
        self.abstract = abstract
        self.keywords = keywords
        self.review = review
        self.type = type
        self.source = source
        self.idgen = idgen
        self.idnew = idnew
        self.doi = doi
        self.attributes = attributes