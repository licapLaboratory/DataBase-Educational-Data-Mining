import author as Author
import article as Article

class AuthorList:
    def __init__(self):
        self.author_list = []

    def addEntry(self, author_name, article):
        index = next((i for i, item in enumerate(self.author_list) if item.author_name == author_name), -1)
        if index != -1: 
            self.author_list[index].articles_from_author.append(article)
        else:
            auth = Author.Author(author_name, article)
            self.author_list.append(auth)

    def load_tsv(self, filename):
        file = open(filename, 'r', encoding='utf_8')
        Lines = file.readlines()  
        count = 0

        for line in Lines:
            # id_BibTex, Year, Authors, Title, Abstract, keywords, review, material_type, source, idgen, idnew, doi
            parts = line.split("\t")

            id_BibTex = parts[0]
            year = parts[1]
            authors = parts[2]
            title = parts[3]
            abstract = parts[4]
            keywords = parts[5]
            review = parts[6]
            material_type = parts[7]
            source = parts[8]
            idgen = parts[9]
            idnew = parts[10]
            doi = parts[11]
            attributes = parts[12].strip()
            for author in authors.split(" and "):
                art = Article.Article(bibtexID=id_BibTex, year=year, title=title, abstract=abstract, keywords=keywords, review=review, type=material_type, source=source, idgen=idgen, idnew=idnew,doi=doi, attributes=attributes)
                self.addEntry(author, art)
            count += 1

    def getAuthors(self, bibTex):
        auList = []
        for i, item in enumerate(self.author_list):
            for article in item.articles_from_author:
                if article.bibtexID == bibTex:
                    auList.append(item)
        return auList
                    
    def getArticles(self, author_names):
        arList = []
        for author_name in author_names:
            index = next((i for i, item in enumerate(self.author_list) if item.author_name == author_name), -1)
            if index != -1: 
                for article in self.author_list[index].articles_from_author:
                    arList.append(article)    
        return arList

    def createJavaQueryFromAuthor(self, author_name):
        # 0;n;a1,a2,a3,an 1;n;a1,a2,a3,an 2;n;c1,c2,c3,cn
        index = next((i for i, item in enumerate(self.author_list) if item.author_name == author_name), -1)
        if index != -1: 
            for article in self.author_list[index].articles_from_author:
                print(article.title)

        attribute_range = ["Teaching","Traditional_classroom","eLearning","Student","Educator","Tutor","Administrator","Coordinator","Classroom","Virtual_classroom","Teaching_plan","Student_groups","Interdisciplinary","Multimedia","Monitoring","Personalization","Evaluation","Learning"]
        out = ""
        out += "1;"
        count = 0
        buf = ""
        for i, att in enumerate(attribute_range):
            if article.attributes[i] == '1':
                buf += att + "#"
                count +=1
        if count > 1:
            buf = buf[:-1]
        out += str(count)
        out += buf
        out += " 2;1;"
        out += obtainYearRange(int(article.year))
        return out
                    
    def createJavaQueryFromArticle(self, bibTex, withAuthors = True, withArticles=True, withConditions=True):
        query = []
        authorsInArticle = []
        articleWanted = None

        for i, item in enumerate(self.author_list):
            for article in item.articles_from_author:
                if article.bibtexID == bibTex:
                    articleWanted = article
        for i, item in enumerate(self.author_list):
            if isArticleInArticleList(bibTex, item.articles_from_author):
                authorsInArticle.append(item.author_name)
        
        if withAuthors:
            query.append(FormatAuthors(authorsInArticle))
        if withArticles:
            query.append(FormatArticle(articleWanted)[0])    
        if withConditions:
            query.append(FormatArticle(articleWanted)[1])
        return query
                
def isArticleInArticleList(bibTex, articles):
    isInArticleList = False
    for i, article in enumerate(articles):
        if article.bibtexID == bibTex:
            isInArticleList = True

    return isInArticleList

def FormatAuthors(auths):
    # 0;a1,a2,a3,an 1;a1,a2,a3,an 2;c1,c2,c3,cn
    out = "0;"
    buf = ""
    for i, auth in enumerate(auths):
        buf += auth + "#"
    buf = buf[:-1].replace(" ", "_")
    out += buf + " "
    return out


def FormatArticle(article):
    # 0;a1,a2,a3,an 1;a1,a2,a3,an 2;c1,c2,c3,cn
    attribute_range = ["Teaching","Traditional_classroom","eLearning","Student","Educator","Tutor","Administrator","Coordinator","Classroom","Virtual_classroom","Teaching_plan","Student_groups","Interdisciplinary","Multimedia","Monitoring","Personalization","Evaluation","Learning"]
    attributes = ""
    attributes += "1;"
    buf = ""
    for i, att in enumerate(attribute_range):
        if article.attributes[i] == '1':
            buf += att + "#"            
    buf = buf[:-1].replace(" ", "_")
    attributes += buf
    attributes += " "
    conditions = "2;"
    conditions += obtainYearRange(int(article.year))
    output = []
    output.append(attributes)
    output.append(conditions)
    return output

def obtainYearRange(year):
    if int(year) <= 1999:
        return "1994-1999"
    elif int(year) <= 2005:
        return "2000-2005"
    elif int(year) <= 2011:
        return "2006-2011"
    elif int(year) <= 2017:
        return "2012-2017"
    else:
        return "2018-2020"

# def getRelated(args, outputType = 0, ogVal = None):
#     # Store names of authors and articles received from java program
#     related_author_names = []
#     related_articles = []
    
#     output = runJavaProgram(args)

#     related_author_names = parseJavaOutputAuthors(output)

#     for art in getArticles(related_author_names):
#         if not isArticleInList(art, related_articles):
#             related_articles.append(art)

#     # Prints the results in a formatted way
#     printFormattedArticles(related_articles, outputType, ogVal)

def isArticleInList(article, listOfArticless):
    for inListArticles in listOfArticless:
        if inListArticles.bibtexID == article.bibtexID:
            return True
    return False

def printFormattedArticles(articleList, artType = 0, ogVal = None):         
    if ogVal != None:
        originalID = '\033[0;33;40m ' + ogVal + '\033[0;0m'
        print("Related articles of :", originalID)

    print('[', end='')
    for art in articleList[:-1]:
        if ogVal != art.bibtexID:
            print('\'' + '\033[1;34;40m' + chooseArticleOutputType(art, artType) + '\033[0;0m' + '\'', end=', ')
        else:
            print('\'' + '\033[1;33;40m' + chooseArticleOutputType(art, artType)  + '\033[0;0m' + '\'', end=', ')
    last_element = articleList[len(articleList)-1]
    if ogVal != last_element.bibtexID:
        print('\'' + '\033[1;34;40m' + chooseArticleOutputType(last_element, artType) + '\033[0;0m' + '\'', end='')
    else:
        print('\'' + '\033[1;33;40m' + chooseArticleOutputType(last_element, artType) + '\033[0;0m' + '\'', end='')
    print(']')
    
    print()

def chooseArticleOutputType(article, artType):
    if artType == 0:
        return article.bibtexID
    elif artType == 1:
        return article.title
    return "Error"