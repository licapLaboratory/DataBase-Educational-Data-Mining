import sys
import os.path,subprocess
import random
import statistics

class TestManager:
    author_sample_sizes = [500, 1000, 1500, 1932]
    attribute_sample_sizes = [2, 4, 8, 15]
    condition_sample_sizes = [1, 2, 3, 5]
    sample_sizes = [author_sample_sizes,
                    attribute_sample_sizes,
                    condition_sample_sizes]

    def __init__(self):
        self.author_list = []
        self.attribute_list = []
        self.condition_list = []
        self.load_authors()
        self.load_attributes()
        self.load_conditions()
        self.dimensions = [self.author_list, 
                           self.attribute_list,
                           self.condition_list]

    def load_authors(self):
        file = open("C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/dimension_lists/author_list.txt", 'r', encoding='utf_8')
        Lines = file.readlines()

        for line in Lines:
            self.author_list.append(line.strip())

    def load_attributes(self):
        file = open("C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code//dimension_lists/attribute_list.txt", 'r', encoding='utf_8')
        Lines = file.readlines()

        for line in Lines:
            self.attribute_list.append(line.strip())

    def load_conditions(self):
        file = open("C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code//dimension_lists/condition_list.txt", 'r', encoding='utf_8')
        Lines = file.readlines()

        for line in Lines:
            self.condition_list.append(line.strip())

    def run_in_cmd(self, in_filepath = "C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/inputs/input.txt"):
        cmdCommand = ['py', 'C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/main.py', '<', in_filepath]
        output = 0.0
        try:
            output = (subprocess.check_output(cmdCommand, shell=True)).decode('utf-8')
        except:
            return -1.0
            print()
        # else:
            # print("Acerto")
        runtime = (float(output))
        return runtime

    def generate_input_file1D(self, sample, id):
        # create the file where the inputs will be stored
        input_filename = "C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/inputs/input.txt"
        out = open(input_filename, 'w', encoding='utf_8')

        # set the query ID
        out.write(f'{id}\n')
        # print each element of the sample
        for element in sample:
            out.write(f'{element}\n')
        out.write('0\n')
        out.write('0\n')

    def generate_input_file2D(self, sample1, sample2, id):
        # create the file where the inputs will be stored
        input_filename = "C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/inputs/input.txt"
        out = open(input_filename, 'w', encoding='utf_8')

        # set the query ID
        out.write(f'{id}\n')
        # print each element of the sample
        for element in sample1:
            out.write(f'{element}\n')
        out.write('0\n')
        for element in sample2:
            out.write(f'{element}\n')
        out.write('0\n')
        out.write('0\n')

    def generate_input_file3D(self, sample1, sample2, sample3, id):
        # create the file where the inputs will be stored
        input_filename = "C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/inputs/input.txt"
        out = open(input_filename, 'w', encoding='utf_8')

        # set the query ID
        out.write(f'{id}\n')
        # print each element of the sample
        for element in sample1:
            out.write(f'{element}\n')
        out.write('0\n')
        for element in sample2:
            out.write(f'{element}\n')
        out.write('0\n')
        for element in sample3:
            out.write(f'{element}\n')
        out.write('0\n')
        out.write('0\n')

    def run_tests(self):
        # 1D tests
        runtimes_1D = []
        for dimension_index, dim in enumerate(self.dimensions):
            dimension_runtime = []
            for sample_index, sample_size in enumerate(self.sample_sizes[dimension_index]):
                sample_runtimes = []
                for i in range (100):
                    sample = random.sample(dim, sample_size)
                    self.generate_input_file1D(sample, 3 + dimension_index)
                    sample_runtimes.append(self.run_in_cmd())
                dimension_runtime.append(sample_runtimes)
            runtimes_1D.append(dimension_runtime)

        # Saving 1D result statistics
        out = open("1D_statistics.csv", 'w', encoding='utf_8')
        out.write("Objects,avgtime,totaltime,std,Attributes,avgtime,totaltime,std,Conditions,avgtime,totaltime,std")
        for sample_index in range(4):
            out.write(f'\n')
            for dimension_index, dim in enumerate(self.dimensions):
                out.write(f'{self.sample_sizes[dimension_index][sample_index]},')
                out.write(f'{statistics.mean(runtimes_1D[dimension_index][sample_index])},{sum(runtimes_1D[dimension_index][sample_index])},{statistics.stdev(runtimes_1D[dimension_index][sample_index])},')
        out.write(f'\n')
        out.close()

        # # 2D tests
        runtimes_2D = []
        # Objects and Attributes
        out = open("2D_statistics.csv", 'w', encoding='utf_8')
        out.write(",,,,,,,Attributes,,,,,\n")
        out.write(",,2,,,4,,,8,,,15\n")
        out.write("Objects,avgtime,totaltime,std,avgtime,totaltime,std,avgtime,totaltime,std,avgtime,totaltime,std")
        for author_sample_size in self.author_sample_sizes:
            out.write(f'\n{author_sample_size},')
            for attribute_sample_size in self.attribute_sample_sizes:
                local_runtimes = []
                for i in range (100):
                    author_sample = random.sample(self.author_list, author_sample_size)
                    attribute_sample = random.sample(self.attribute_list, attribute_sample_size)
                    self.generate_input_file2D(author_sample, attribute_sample, 6)
                    local_runtimes.append(self.run_in_cmd())
                out.write(f'{statistics.mean(local_runtimes)},{sum(local_runtimes)},{statistics.stdev(local_runtimes)},')
        out.write(f'\n')

        out.write(",,,,,,,Conditions,,,,,\n")
        out.write(",,1,,,2,,,3,,,5\n")
        out.write("Objects,avgtime,totaltime,std,avgtime,totaltime,std,avgtime,totaltime,std,avgtime,totaltime,std")
        for author_sample_size in self.author_sample_sizes:
            out.write(f'\n{author_sample_size},')
            for condition_sample_size in self.condition_sample_sizes:
                local_runtimes = []
                for i in range (100):
                    author_sample = random.sample(self.author_list, author_sample_size)
                    condition_sample = random.sample(self.condition_list, condition_sample_size)
                    self.generate_input_file2D(author_sample, condition_sample, 7)
                    local_runtimes.append(self.run_in_cmd())
                out.write(f'{statistics.mean(local_runtimes)},{sum(local_runtimes)},{statistics.stdev(local_runtimes)},')
        out.write(f'\n')

        out.write(",,,,,,,Conditions,,,,,\n")
        out.write(",,1,,,2,,,3,,,5\n")
        out.write("Attributes,avgtime,totaltime,std,avgtime,totaltime,std,avgtime,totaltime,std,avgtime,totaltime,std")
        for attribute_sample_size in self.attribute_sample_sizes:
            out.write(f'\n{attribute_sample_size},')
            for condition_sample_size in self.condition_sample_sizes:
                local_runtimes = []
                for i in range (100):
                    attribute_sample = random.sample(self.attribute_list, attribute_sample_size)
                    condition_sample = random.sample(self.condition_list, condition_sample_size)
                    self.generate_input_file2D(attribute_sample, condition_sample, 8)
                    local_runtimes.append(self.run_in_cmd())
                out.write(f'{statistics.mean(local_runtimes)},{sum(local_runtimes)},{statistics.stdev(local_runtimes)},')
        out.close()

        # 3D tests
        runtimes_3D = []
        # Objects and Attributes
        out = open("3D_statistics.csv", 'w', encoding='utf_8')
        for attribute_sample_size in self.attribute_sample_sizes:
            out.write(",,,,,,,Attributes,,,,,\n")
            out.write(f',,,,,,,{attribute_sample_size},,,,,\n')
            out.write(",,,,,,,Conditions,,,,,\n")
            out.write(',,1,,,2,,,3,,,5\n')
            out.write("Objects,avgtime,totaltime,std,avgtime,totaltime,std,avgtime,totaltime,std,avgtime,totaltime,std")
            for author_sample_size in self.author_sample_sizes:
                out.write(f'\n{author_sample_size},')
                for condition_sample_size in self.condition_sample_sizes:
                    local_runtimes = []
                    for i in range (100):
                        author_sample = random.sample(self.author_list, author_sample_size)
                        attribute_sample = random.sample(self.attribute_list, attribute_sample_size)
                        condition_sample = random.sample(self.condition_list, condition_sample_size)
                        self.generate_input_file3D(author_sample, attribute_sample, condition_sample, 9)
                        local_runtimes.append(self.run_in_cmd())
                    out.write(f'{statistics.mean(local_runtimes)},{sum(local_runtimes)},{statistics.stdev(local_runtimes)},')
            out.write(f'\n')
        

        out.close()


    # def find_badly_typed_authors(self):
    #     for author in self.author_list:
    #         fake_list = []
    #         fake_list.append(author)
    #         self.generate_input_file(fake_list, 3)
    #         flag = self.run_in_cmd()
    #         if flag < 0:
    #             print("Wrong: " + author)
    #         else :
    #             print("Correct: " + author)

tm = TestManager()
tm.run_tests()
            

