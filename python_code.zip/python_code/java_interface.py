import sys
import os.path,subprocess

def runJavaProgram(args):
    cmdCommand = ['Java', '-jar', 'C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/JavaCode.jar']
    for arg in args:
        cmdCommand.append(arg.replace(' ', ''))
    output = (subprocess.check_output(cmdCommand)).decode('utf-8')
    return output
    
# Parses the java application output and returns a list of authors identified
def parseJavaOutputAuthors(javaOutput):
    java_authors = []
    # Parse output
    output_lines = (javaOutput.splitlines()[2:])[:-2]
    # Get authors from output
    for line in output_lines:
        author_part = (line.split('],')[0])[2:]
        for name in author_part.split(', '):
            if name.replace('_', ' ') not in java_authors:
                java_authors.append(name.replace('_', ' '))
    return java_authors
    
# Parses the java application output and returns a list of authors identified
def parseJavaOutput(javaOutput):
    formattedOutput = []
    # Parse output
    output_lines = (javaOutput.splitlines()[2:])[:-2]
    # Get authors from output
    for line in output_lines:
        parts = (line.split('],'))
        formattedOutput.append((clearCharacters(parts[0], '[', '{', '}', ']'), clearCharacters(parts[1], '[', '{', '}', ']'), clearCharacters(parts[2], '[', '{', '}', ']')))
    return formattedOutput

def printJavaParsedOutput(javaOutput, clipped=True):
    for line in javaOutput:
        if(clipped):
            print('[' + line[0][0:40] + '],', end='')
        else:
            print('[' + line[0] + '],', end='')
        print('[' + line[1] + '],', end='')
        print('[' + line[2] + ']')

def clearCharacters(originalString, *characters):
    newString = originalString
    for char in characters:
        newString = newString.replace(char, '')
    return newString

def objectsToQuery(objects):
    query = '0;'
    
    if len(objects) > 0:
        for t in objects:
            query += t + '#'
    query = query[:-1]

    return query

def attributesToQuery(attributes):
    query = '1;'
    
    if len(attributes) > 0:
        for t in attributes:
            query += t + '#'
    query = query[:-1]

    return query

def conditionsToQuery(conditions):
    query = '2;'
    
    if len(conditions) > 0:
        for t in conditions:
            query += t + '#'
    query = query[:-1]

    return query