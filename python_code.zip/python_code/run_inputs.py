import sys
import os.path,subprocess

def read_list(filename):
    global total_count
    file = open(filename, 'r', encoding='utf_8')
    Lines = file.readlines()
    file_list = []

    for line in Lines:
        file_list.append(line.strip())
    return file_list

def run_in_cmd(in_filepath):
    out_filepath = in_filepath.replace(".in", ".out")
    cmdCommand = ['py', 'C:/Projects/iniciacaoCientifica/my_auxiliary_code/python_code/main.py', '<', in_filepath]
    time = 0.0
    for i in range(100):
        output = (subprocess.check_output(cmdCommand, shell=True)).decode('utf-8')
        time += float(output.split(" ")[1])
    out = open(out_filepath, 'w', encoding='utf_8')
    out.write(f'Total time: {time} seconds\n')
    out.write(f'Average time: {time/100} seconds')

object_sizes = [500, 1000, 1500, 1932]
attribute_sizes = [2, 4, 8, 15]
condition_sizes = [1, 2, 3, 5]

for obj_size in object_sizes:
    for attr_size in attribute_sizes:
            filepath = "../python_code/inputs/2D/2D_oa/input_2D_o" + str(obj_size) + "a" + str(attr_size) + ".in"
            run_in_cmd(filepath)

for obj_size in object_sizes:
        for cond_size in condition_sizes:
            filepath = "../python_code/inputs/2D/2D_oc/input_2D_o" + str(obj_size) + "c" + str(cond_size) + ".in"
            run_in_cmd(filepath)

for attr_size in attribute_sizes:
    for cond_size in condition_sizes:
        filepath = "../python_code/inputs/2D/2D_ac/input_2D_" + "a" + str(attr_size) + "c" + str(cond_size) + ".in"
        run_in_cmd(filepath)

for obj_size in object_sizes:
    for attr_size in attribute_sizes:
        for cond_size in condition_sizes:
            filepath = "../python_code/inputs/3D/input_3D_o" + str(obj_size) + "a" + str(attr_size) + "c" + str(cond_size) + ".in"
            run_in_cmd(filepath)

# run_in_cmd("../python_code/inputs/1D_authors/1D_500_authors.in")
# run_in_cmd("../python_code/inputs/1D_authors/1D_1000_authors.in")
# run_in_cmd("../python_code/inputs/1D_authors/1D_1500_authors.in")
# run_in_cmd("../python_code/inputs/1D_authors/1D_1932_authors.in")

# run_in_cmd("../python_code/inputs/1D_attributes/1D_2_attributes.in")
# run_in_cmd("../python_code/inputs/1D_attributes/1D_4_attributes.in")
# run_in_cmd("../python_code/inputs/1D_attributes/1D_8_attributes.in")
# run_in_cmd("../python_code/inputs/1D_attributes/1D_15_attributes.in")

# run_in_cmd("../python_code/inputs/1D_conditions/1D_1_conditions.in")
# run_in_cmd("../python_code/inputs/1D_conditions/1D_2_conditions.in")
# run_in_cmd("../python_code/inputs/1D_conditions/1D_3_conditions.in")
# run_in_cmd("../python_code/inputs/1D_conditions/1D_5_conditions.in")