class Result:
    def __init__(self, author_name, article):
        self.articles_from_author = []
        self.author_name = author_name 
        self.articles_from_author.append(article)
